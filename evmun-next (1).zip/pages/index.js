export default function Home() {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans">
      <header className="bg-gray-900 text-white py-6 shadow-lg">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center">
          <h1 className="text-3xl font-bold">EVMUN 2025</h1>
          <nav className="space-x-6 mt-4 md:mt-0">
            <a href="#about" className="hover:underline">About</a>
            <a href="#committees" className="hover:underline">Committees</a>
            <a href="#register" className="hover:underline">Register</a>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <section className="text-center mb-16">
          <h2 className="text-4xl font-semibold mb-4">Welcome to EDUVATION'S Model United Nations</h2>
          <p className="text-lg mb-6">Join us for a day of diplomacy, debate, and discovery.</p>
          <p className="text-md">📍 XYZ School | 📅 23 June 2025</p>
        </section>

        {/* About Section */}
        <section id="about" className="mb-16">
          <h3 className="text-2xl font-semibold mb-4">About EVMUN</h3>
          <p className="text-gray-700">
            EVMUN brings together aspiring diplomats and changemakers from schools across the region
            to discuss and resolve global issues through engaging debate and collaboration. Whether
            you're a seasoned delegate or a first-timer, EVMUN 2025 promises a platform for learning,
            leadership, and international understanding.
          </p>
        </section>

        {/* Committees Section */}
        <section id="committees" className="mb-16">
          <h3 className="text-2xl font-semibold mb-6">Committees</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {["UNDP", "UNSC", "UNGA", "WHO"].map(committee => (
              <div key={committee} className="border p-6 rounded-xl shadow hover:shadow-lg transition">
                <h4 className="text-xl font-bold">{committee}</h4>
                <p className="text-gray-600 mt-2">Engage in real-world issues facing the international community.</p>
              </div>
            ))}
          </div>
        </section>

        {/* Register Section */}
        <section id="register" className="text-center">
          <h3 className="text-2xl font-semibold mb-4">Ready to Join?</h3>
          <a
            href="https://www.evmun.register.in"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow hover:bg-blue-700 transition"
          >
            Register Now
          </a>
        </section>
      </main>

      <footer className="bg-gray-100 text-center py-6 text-sm text-gray-600">
        © 2025 EVMUN. All rights reserved.
      </footer>
    </div>
  )
}